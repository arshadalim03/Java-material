package com.cg.mobile.dao;

import java.util.List;


import com.cg.mobile.dto.Mobiles;
import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.exception.MobileException;

public interface IMobileDao {
	
	public PurchaseDetails addDetails(PurchaseDetails purchase) throws MobileException;
	public Mobiles updateDetails(int quantity, int mobileId) throws MobileException;
	public List<Mobiles> getMobileList() throws MobileException;
	public Mobiles deleteDetails(int mobileId) throws MobileException;
	public List<Mobiles> inBetween(int min, int max) throws MobileException;
	
}
