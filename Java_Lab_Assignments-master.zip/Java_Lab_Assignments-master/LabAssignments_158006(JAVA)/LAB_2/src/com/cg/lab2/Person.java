package com.cg.lab2;

import java.util.Scanner;


enum Gender{
	M("Male"),F("Female");
	
	private String name;
	Gender(String gen){
		name = gen;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}

public class Person {
	
	String first_name;
	String last_name;
	Gender gender;
	int phone;
	public int number;

    // Parameterized Constructor
	public Person(String first_name, String last_name, Gender gender, int phone) {
		super();
		this.first_name = first_name;
		this.last_name = last_name;
		this.gender = gender;
		this.phone = phone;
	}

    //Default Constructor
	public Person(){
		first_name = "First Name";
		last_name = "Last Name";
		phone = 12345;
		gender = Gender.M;
		
	}
	
	
	
	@Override
	public String toString()
	{
		return first_name+" "+last_name+" "+gender+" "+phone;
	}
	
	
	//Getter and Setters
	
	public String getfirst_name() {
		return first_name;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public void setfirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getlast_name() {
		return last_name;
	}

	public void setlast_name(String last_name) {
		this.last_name = last_name;
	}

	

	//Phone number method
	public int phonenum() {
		System.out.println("Enter the phone number: ");
		Scanner scan = new Scanner(System.in);
		phone = scan.nextInt();
		return phone;
	}
	
	public void scan() {
		// TODO Auto-generated method stub
		System.out.println("Enter Fisrt Name:");
		Scanner first = new Scanner(System.in);
		this.first_name = first.next();
	
		System.out.println("Enter Last Name:");
		Scanner second = new Scanner(System.in);
		this.last_name = second.next(); 
		
		System.out.println("Enter Gender(M/F):");
		Scanner pnum = new Scanner(System.in);
		char Gen = pnum.next().charAt(0);
		if(Gen == 'M')
		{
			Gender gen = Gender.M;
			this.gender = gen;
		}
		else if(Gen == 'F'){
			Gender gen = Gender.F;
			this.gender = gen;
		}
		
	}
	
	
    //Display method
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("Person Details:");
		System.out.println("-----------------");
		System.out.println("First name: "+ first_name  );
		System.out.println("Last name: "+ last_name);
		System.out.println("Gender: "+getGender().getName());
		System.out.println("Phone Number: " + phone);
	//	System.out.println("Gender: "+ );
	}

	
	
}
