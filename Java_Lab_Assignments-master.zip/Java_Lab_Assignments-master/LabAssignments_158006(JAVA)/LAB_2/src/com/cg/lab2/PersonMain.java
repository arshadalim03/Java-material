package com.cg.lab2;

import java.util.Scanner;

public class PersonMain{

public static void main(String[] args) {
		
	 
		Person person = new Person();
		person.scan();
		person.phonenum();
		person.print();
		
	}
	
	
}
