package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.IEmployeeService;
import com.cg.eis.service.InsuranceService;

public class UserInterface {
public static void main(String[] args) {
	Employee emp= new Employee();
	IEmployeeService service = new InsuranceService();
	Scanner sc = new Scanner (System.in);
	
	System.out.println("Enter employee ID ");
	int ID = sc.nextInt();
	
	System.out.println("Enter employee name:");
	String name = sc.next();
	
	 System.out.println("Enter salary:");
	 long salary= sc.nextLong();
			 
	 System.out.println("Enter designation ");
	 String designation = sc.next();
	 
	 emp.setId(ID);
	 emp.setName(name);
	 emp.setSalary(salary);
	 emp.setDesignation(designation);
	
	System.out.println(service.getInsuranceScheme(emp)); 
}
}
