package com.cg.empservice;

import com.cg.exception.EmployeeException;
import com.cg.lab10.Employee;

public interface IEmpService {
	public Employee addEmployee(Employee employee)throws EmployeeException;
}
