package com.cg.lab9;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.junit.Test;

public class TestPersonDetails {

	@Test
	public void testGetFirstName(){
		System.out.println("From TestPersonDetails getF_name");
		PersonDetails person = new PersonDetails("Robert", "King", 'M', 55,70.0, "7053855190");
		assertEquals("Robert", person.getF_name());
	}
	
	@Test
	public void testGetLastName(){
		System.out.println("From TestPersonDetails getL_name");
		PersonDetails person = new PersonDetails("Robert", "King", 'M', 55,70.0, "7053855190");
		assertEquals("King", person.getL_name());
	}
	
	@Test
	public void testGetGender(){
		System.out.println("From TestPersonDetails getGen");
		PersonDetails person = new PersonDetails("Robert", "King", 'M', 55,70.0, "7053855190");
		assertEquals('M', person.getGen());
	}
	
	@Test
	public void testGetAge(){
		System.out.println("From TestPersonDetails getAge");
		PersonDetails person = new PersonDetails("Robert", "King", 'M', 55,70.0, "7053855190");
		assertEquals(55, person.getAge());
	}
	
	@Test
	public void testGetWeight(){
		System.out.println("From TestPersonDetails getWeight");
		PersonDetails person = new PersonDetails("Robert", "King", 'M', 55,70.0, "7053855190");
		assertEquals(70.0, person.getWht(),0.001);
		
	}

	@Test
	public void testGetPhoneNo(){
		System.out.println("From TestPersonDetails getPhoneNo");
		PersonDetails person = new PersonDetails("Robert", "King", 'M', 55,70.0, "7053855190");
		assertEquals("8087206609", person.getPhno());
		
	}
	@Test 
	public void testSetFirstName(){
		PersonDetails person = new PersonDetails("Robert", "King", 'M', 55,70.0, "7053855190");
		person.setF_name("Shekhar");
		assertTrue(person.getF_name() == "Shekhar");
	}
	
	@Test 
	public void testSetLastName(){
		PersonDetails person = new PersonDetails("Robert", "King", 'M', 55,70.0, "7053855190");
		person.setL_name("Singh");
		assertTrue(person.getL_name() == "Singh");
	}
	
	@Test 
	public void testSetAge(){
		PersonDetails person = new PersonDetails("Robert", "King", 'M', 55,70.0, "7053855190");
		person.setAge(22);
		assertTrue(person.getAge() == 22);
	}
	
	@Test 
	public void testSetWeight(){
		PersonDetails person = new PersonDetails("Robert", "King", 'M', 55,70.0, "7053855190");
		person.setWht(55);
		assertTrue(person.getWht() == 55);
	}
	
	@Test 
	public void testSetPhno(){
		PersonDetails person = new PersonDetails("Robert", "King", 'M', 55,70.0, "7053855190");
	String phno ="9876256980"; 
	InputStream in = new ByteArrayInputStream(phno.getBytes());
	 System.setIn(in);
		assertEquals("9876256980", person.setPhno());
		
	}
}
